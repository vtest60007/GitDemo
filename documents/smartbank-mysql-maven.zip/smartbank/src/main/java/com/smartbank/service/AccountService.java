
package com.smartbank.service;

import com.smartbank.model.Account;
import com.smartbank.model.Customer;
import com.smartbank.patterns.Notifier;

import java.util.ArrayList;
import java.util.List;

public class AccountService {
    private final BankRepository repo;
    private final List<Notifier> notifiers = new ArrayList<>();

    public AccountService(BankRepository repo) { this.repo = repo; }
    public void addNotifier(Notifier n) { notifiers.add(n); }

    private void notifyAll(Customer c, String msg) {
        notifiers.forEach(n -> n.notify(c, msg));
    }

    public void deposit(String accountNumber, double amount) {
        Account acc = repo.getAccount(accountNumber);
        acc.deposit(amount);
        notifyAll(acc.getOwner(), "Deposit of " + amount + " to " + accountNumber);
    }
}
