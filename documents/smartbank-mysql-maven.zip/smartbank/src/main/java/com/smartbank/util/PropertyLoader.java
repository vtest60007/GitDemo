
package com.smartbank.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyLoader {
    private final Properties props = new Properties();
    public PropertyLoader() {
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("application.properties")) {
            if (in != null) props.load(in);
        } catch (IOException e) {
            throw new RuntimeException("Could not load application.properties", e);
        }
    }
    public String get(String key) { return props.getProperty(key); }
}
