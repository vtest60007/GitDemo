
package com.smartbank.util;

import com.smartbank.annotations.Auditable;

import java.lang.reflect.Method;

public class AnnotationAuditor {
    public static void scanAndLog(Object service, AuditLogger logger) throws Exception {
        for (Method m : service.getClass().getDeclaredMethods()) {
            if (m.isAnnotationPresent(Auditable.class)) {
                logger.log("Auditable method found: " + m.getName());
            }
        }
    }
}
