
package com.smartbank.util;

public final class BankConstants {
    private BankConstants() {}
    public static final double SAVINGS_INTEREST_RATE = 0.035;
    public static final double CURRENT_OVERDRAFT_LIMIT = 10000.0;

    public static String generateAccountNumber() {
        return "SB-" + System.currentTimeMillis();
    }
}
