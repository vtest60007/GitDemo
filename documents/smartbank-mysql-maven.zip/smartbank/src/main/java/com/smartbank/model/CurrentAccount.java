
package com.smartbank.model;

import com.smartbank.util.BankConstants;
import com.smartbank.model.exceptions.InsufficientBalanceException;

public class CurrentAccount extends Account {
    public CurrentAccount(String accountNumber, Customer owner, double openingBalance) {
        super(accountNumber, owner, openingBalance);
    }
    @Override
    public void withdraw(double amount) throws InsufficientBalanceException {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        double prospective = balance - amount;
        if (prospective < -BankConstants.CURRENT_OVERDRAFT_LIMIT) {
            throw new InsufficientBalanceException("Overdraft limit exceeded");
        }
        balance -= amount;
    }
    @Override
    public double calculateInterest() {
        return 0.0; // Typically no interest for current accounts
    }
}
