
package com.smartbank.patterns;

import com.smartbank.model.*;
import com.smartbank.util.BankConstants;

public class AccountFactory {
    public static Account create(AccountType type, Customer owner, double openingBalance) {
        String accNo = BankConstants.generateAccountNumber();
        switch (type) {
            case SAVINGS: return new SavingsAccount(accNo, owner, openingBalance);
            case CURRENT: return new CurrentAccount(accNo, owner, openingBalance);
            default: throw new IllegalArgumentException("Unknown type");
        }
    }
}
