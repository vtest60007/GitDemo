
package com.smartbank.app;

import com.smartbank.dao.AccountDao;
import com.smartbank.dao.CustomerDao;
import com.smartbank.dao.TransactionDao;
import com.smartbank.model.*;
import com.smartbank.patterns.AccountFactory;
import com.smartbank.patterns.DbConnectionManager;
import com.smartbank.service.BankRepository;
import com.smartbank.service.AccountService;
import com.smartbank.util.PropertyLoader;

import java.sql.Connection;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        PropertyLoader props = new PropertyLoader();
        String url = props.get("db.url");
        String user = props.get("db.username");
        String pass = props.get("db.password");

        DbConnectionManager db = DbConnectionManager.getInstance();
        db.init(url, user, pass);
        Connection conn = db.getConnection();

        CustomerDao customerDao = new CustomerDao(conn);
        AccountDao accountDao = new AccountDao(conn);
        TransactionDao txDao = new TransactionDao(conn);

        BankRepository repo = new BankRepository();
        AccountService accountService = new AccountService(repo);

        Scanner sc = new Scanner(System.in);
        System.out.println("SmartBank CLI");
        System.out.println("1) Create customer & savings account
2) Deposit
3) Exit");
        while (true) {
            System.out.print("Choose: ");
            int ch = Integer.parseInt(sc.nextLine());
            if (ch == 1) {
                System.out.print("First name: "); String fn = sc.nextLine();
                System.out.print("Last name: "); String ln = sc.nextLine();
                System.out.print("Email: "); String em = sc.nextLine();
                Customer c = new Customer(fn, ln, em);
                customerDao.insert(c);
                Account acc = AccountFactory.create(AccountType.SAVINGS, c, 1000.0);
                accountDao.insert(acc, AccountType.SAVINGS);
                repo.addCustomer(c);
                repo.addAccount(acc);
                System.out.println("Created account: " + acc.getAccountNumber());
            } else if (ch == 2) {
                System.out.print("Account number: "); String accNo = sc.nextLine();
                System.out.print("Amount: "); double amt = Double.parseDouble(sc.nextLine());
                accountService.deposit(accNo, amt);
                txDao.insert(accNo, "CREDIT", amt);
                System.out.println("Deposited.");
            } else { break; }
        }
        sc.close();
    }
}
