
package com.smartbank.service;

import com.smartbank.model.Account;
import com.smartbank.model.exceptions.InsufficientBalanceException;

import java.sql.Connection;
import java.sql.Savepoint;

public class TransferService {
    private final Connection conn;
    private final com.smartbank.dao.AccountDao accountDao;
    private final com.smartbank.dao.TransactionDao txDao;

    public TransferService(Connection conn, com.smartbank.dao.AccountDao accountDao, com.smartbank.dao.TransactionDao txDao) {
        this.conn = conn; this.accountDao = accountDao; this.txDao = txDao;
    }

    public void transfer(String fromAcc, String toAcc, double amount) throws Exception {
        conn.setAutoCommit(false);
        Savepoint sp = null;
        try {
            Account src = accountDao.findByNumber(fromAcc);
            Account dst = accountDao.findByNumber(toAcc);

            src.withdraw(amount);
            dst.deposit(amount);

            accountDao.updateBalance(src.getAccountNumber(), src.getBalance());
            accountDao.updateBalance(dst.getAccountNumber(), dst.getBalance());

            txDao.insert(fromAcc, "DEBIT", amount);
            txDao.insert(toAcc, "CREDIT", amount);

            sp = conn.setSavepoint("AFTER_TX");
            conn.commit();
        } catch (Exception ex) {
            if (sp != null) conn.rollback(sp); else conn.rollback();
            throw ex;
        } finally {
            conn.setAutoCommit(true);
        }
    }
}
