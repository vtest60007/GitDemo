
package com.smartbank.model;

import com.smartbank.model.Customer;
import com.smartbank.model.exceptions.InsufficientBalanceException;

public abstract class Account {
    private final String accountNumber;
    private Customer owner;
    protected double balance;

    protected Account(String accountNumber, Customer owner, double openingBalance) {
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.balance = openingBalance;
    }

    public void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        balance += amount;
    }

    public abstract void withdraw(double amount) throws InsufficientBalanceException;
    public abstract double calculateInterest();

    public String getAccountNumber() { return accountNumber; }
    public double getBalance() { return balance; }
    public Customer getOwner() { return owner; }
}
