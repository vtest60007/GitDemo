
package com.smartbank.patterns;

import com.smartbank.model.Account;
import com.smartbank.util.BankConstants;

public interface InterestStrategy { double computeInterest(Account account); }

class DefaultSavingsInterest implements InterestStrategy {
    public double computeInterest(Account account) {
        return account.getBalance() * BankConstants.SAVINGS_INTEREST_RATE;
    }
}
