
package com.smartbank.service;

import com.smartbank.model.Account;
import com.smartbank.model.Customer;

import java.util.*;

public class BankRepository {
    private final Map<String, Customer> customersById = new HashMap<>();
    private final Map<String, Account> accountsByNumber = new HashMap<>();
    private final Map<Customer, List<Account>> accountsByCustomer = new HashMap<>();
    private final Set<String> accountNumbers = new HashSet<>();

    public void addCustomer(Customer c) { customersById.put(c.getId(), c); }

    public void addAccount(Account acc) {
        if (!accountNumbers.add(acc.getAccountNumber()))
            throw new IllegalStateException("Duplicate account number");
        accountsByNumber.put(acc.getAccountNumber(), acc);
        accountsByCustomer.computeIfAbsent(acc.getOwner(), k -> new ArrayList<>()).add(acc);
    }
    public Account getAccount(String accNumber) { return accountsByNumber.get(accNumber); }
    public List<Account> getAccounts(Customer c) { return accountsByCustomer.getOrDefault(c, Collections.emptyList()); }
}
