
package com.smartbank.patterns;

import com.smartbank.model.Customer;

public interface Notifier { void notify(Customer customer, String message); }

class EmailNotifier implements Notifier {
    @Override
    public void notify(Customer customer, String message) {
        System.out.printf("Email to %s: %s%n", customer.getEmail(), message);
    }
}

class SmsNotifier implements Notifier {
    @Override
    public void notify(Customer customer, String message) {
        System.out.printf("SMS to %s: %s%n", customer.getEmail(), message);
    }
}
