# Burndown Plan — 12-Day SmartBank Case Study

## Sprint 1 - Days 1-6
- **Total Story Points**: 53
- Duration: 6 days
- Target daily burn: ~8.83 points/day

## Sprint 2 - Days 7-12
- **Total Story Points**: 47
- Duration: 6 days
- Target daily burn: ~7.83 points/day

## Suggested Daily Burn Targets
- Day 1: 8–10 pts (model & skeletons)
- Day 2: 5–6 pts (encapsulation & constants)
- Day 3: 4–5 pts (strings & exceptions)
- Day 4: 8–10 pts (collections & repo)
- Day 5: 8–10 pts (singleton & factory)
- Day 6: 8–10 pts (strategy & observer)
- Day 7: 8–10 pts (schema & DAOs)
- Day 8: 8–10 pts (transactions)
- Day 9: 5–6 pts (concurrency)
- Day 10: 4–5 pts (IO & annotations)
- Day 11: 8–10 pts (streams/reports)
- Day 12: 8–10 pts (CLI/tests/pkg)