
# Jira Setup — SmartBank Agile Project (12-Day Plan)

## 1) Create a Scrum Board
1. Projects → Create project → Template: **Scrum**.
2. Name: **SmartBank** (key: SB).
3. Board → Backlog view.

## 2) Create Sprints
- Sprint 1 — Days 1–6
- Sprint 2 — Days 7–12

## 3) Import Backlog from CSV
1. ⚙️ Settings → **System** → External System Import → **CSV**.
2. Upload `docs/jira-backlog.csv`.
3. Field mappings:
   - Issue Type → Issue Type
   - Summary → Summary
   - Description → Description
   - Epic Name → Epic Name *(only for Epics)*
   - Epic Link → Epic Link *(Stories/Tasks link to an Epic Name)*
   - Sprint → Sprint *(ensure sprints exist before import)*
   - Story Points → Story Points
   - Priority → Priority
   - Labels → Labels
   - Assignee → Assignee
   - Due Date → Due Date *(optional)*

## 4) Recommended Workflow
- **To Do** → **In Progress** → **In Review** → **Done**
- Definition of Done (DoD):
  - Code compiles & static checks pass
  - Unit tests created and passing
  - README/doc updated
  - Demo/CLI scenario validated (where applicable)

## 5) Epics
- Domain & OOP
- Collections & Core
- Patterns & Arch
- JDBC Persistence
- TX & Concurrency
- IO+Anno+Reports
- CLI & Tests

## 6) Reports
- Enable **Burndown** & **Velocity** gadget on the Scrum dashboard.
- Use labels `day-1` ... `day-12` to filter.

## 7) Capacity & Roles (example)
- Dev: 1–2, QA: 1, PO: 1
- Daily standup, sprint planning (Day 1, Day 7), sprint review & retro (Day 6, Day 12).
