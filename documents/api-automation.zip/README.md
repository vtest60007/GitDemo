# API Automation Framework (Beginner to Advanced)

This project demonstrates API testing using Postman and RestAssured.

## Key Concepts
- API testing
- HTTP methods
- Validation
- TestNG framework
- Data-driven testing

## How to run
mvn clean test
