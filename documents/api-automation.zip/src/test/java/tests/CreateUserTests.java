package tests;

import base.BaseTest;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class CreateUserTests extends BaseTest {

    // Test for creating a user
    @Test
    public void createUser() {

        String body = "{ "name": "Venkat", "job": "QA" }";

        given()
            .header("Content-Type", "application/json")
            .body(body)
        .when()
            .post("/users")
        .then()
            // Validate creation status
            .statusCode(201)
            // Validate ID presence
            .body("id", notNullValue());
    }
}
