package tests;

import base.BaseTest;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class GetUserTests extends BaseTest {

    // Test to validate users list API
    @Test
    public void getUsersList() {
        given()
        .when()
            .get("/users?page=2")
        .then()
            // Validate status code
            .statusCode(200)
            // Validate response data size
            .body("data.size()", greaterThan(0))
            // Validate response time
            .time(lessThan(2000L));
    }

    // Test to validate single user
    @Test
    public void getSingleUser() {
        given()
        .when()
            .get("/users/2")
        .then()
            .statusCode(200)
            .body("data.id", equalTo(2));
    }
}
