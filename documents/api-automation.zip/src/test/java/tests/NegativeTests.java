package tests;

import base.BaseTest;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

public class NegativeTests extends BaseTest {

    // Test for non-existing user
    @Test
    public void userNotFound() {
        given()
        .when()
            .get("/users/999")
        .then()
            .statusCode(404);
    }
}
