
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class AdvancedTests {

    public void fullFlow(){
        int id = given()
            .header("Content-Type","application/json")
            .body("{ "title":"API","body":"Test","userId":1 }")
        .when()
            .post("https://jsonplaceholder.typicode.com/posts")
        .then()
            .statusCode(201)
            .extract().path("id");

        given().get("https://jsonplaceholder.typicode.com/posts/"+id)
        .then().statusCode(200);

        given().delete("https://jsonplaceholder.typicode.com/posts/"+id)
        .then().statusCode(200);
    }
}
