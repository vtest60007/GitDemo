
# Velocity & Capacity Planning — SmartBank (12 Days)

## Assumptions
- Team: 2 devs, 1 QA, 1 PO
- Work day: 6–7 effective hours/dev
- Historical velocity: 8–10 story points/day for dev pair on similar scope

## Sprint Capacities
- Sprint 1 (Days 1–6): target ~48–60 pts
- Sprint 2 (Days 7–12): target ~50–60 pts

## Suggested Allocation
- Day 1: 10 pts — domain & skeletons
- Day 2: 6 pts — encapsulation & constants
- Day 3: 5 pts — strings & exceptions
- Day 4: 10 pts — collections & repo
- Day 5: 10 pts — singleton & factory
- Day 6: 10 pts — strategy & observer
- Day 7: 10 pts — schema & DAOs
- Day 8: 10 pts — transactions
- Day 9: 6 pts — concurrency utilities
- Day 10: 5 pts — IO & annotations
- Day 11: 10 pts — streams/reports
- Day 12: 10 pts — CLI/tests/pkg

## QA & Review Cadence
- Daily unit test updates; smoke run of CLI
- Reviews at end of each day; retro at Day 6 & Day 12

## Jira Tips
- Use labels `day-1`…`day-12` and component tags (model, dao, service, patterns)
- Track test coverage growth as a custom metric
