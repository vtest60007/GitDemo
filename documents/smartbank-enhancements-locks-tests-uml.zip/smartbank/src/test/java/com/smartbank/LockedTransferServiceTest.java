
package com.smartbank;

import com.smartbank.model.*;
import com.smartbank.model.exceptions.InsufficientBalanceException;
import com.smartbank.service.BankRepository;
import com.smartbank.service.LockedTransferService;
import org.junit.jupiter.api.Test;

import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.*;

/** Validates ordered lock acquisition prevents deadlocks and preserves balances. */
public class LockedTransferServiceTest {
    @Test
    void concurrentTransfersDoNotDeadlock() throws Exception {
        BankRepository repo = new BankRepository();
        Customer c = new Customer("Test","User","t@smartbank");
        Account a1 = new SavingsAccount("A-001", c, 10000);
        Account a2 = new CurrentAccount("A-002", c, 5000);
        repo.addCustomer(c); repo.addAccount(a1); repo.addAccount(a2);
        LockedTransferService svc = new LockedTransferService(repo);

        ExecutorService es = Executors.newFixedThreadPool(2);
        Future<?> f1 = es.submit(() -> {
            try { svc.transfer("A-001","A-002", 1000); } catch (Exception ignored) {}
        });
        Future<?> f2 = es.submit(() -> {
            try { svc.transfer("A-002","A-001", 700); } catch (Exception ignored) {}
        });
        f1.get(); f2.get(); es.shutdown();

        // Net result should be +700 to A-001 (1000 out, 700 in) and -700 to A-002
        assertEquals(10000 - 1000 + 700, a1.getBalance(), 0.0001);
        assertEquals(5000 + 1000 - 700, a2.getBalance(), 0.0001);
    }
}
