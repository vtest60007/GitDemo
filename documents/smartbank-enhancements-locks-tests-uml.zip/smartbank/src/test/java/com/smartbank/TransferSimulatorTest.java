
package com.smartbank;

import com.smartbank.model.*;
import com.smartbank.model.exceptions.InsufficientBalanceException;
import com.smartbank.service.TransferSimulator;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/** Validates negative-path rollback semantics using in-memory simulator. */
public class TransferSimulatorTest {
    @Test
    void insufficientFundsRollsBack() throws Exception {
        Customer c = new Customer("Rollback","Case","rb@smartbank");
        Account from = new SavingsAccount("RB1", c, 300);
        Account to = new SavingsAccount("RB2", c, 100);
        TransferSimulator sim = new TransferSimulator();

        double fb = from.getBalance();
        double tb = to.getBalance();
        assertThrows(InsufficientBalanceException.class, () -> sim.simulate(from, to, 500));
        // Ensure balances are restored
        assertEquals(fb, from.getBalance(), 0.0001);
        assertEquals(tb, to.getBalance(), 0.0001);
    }
}
