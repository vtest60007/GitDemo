
package com.smartbank.service;

import com.smartbank.model.Account;
import com.smartbank.model.exceptions.InsufficientBalanceException;

/**
 * Pure in-memory transactional simulator to validate negative path semantics
 * without JDBC. On failure, reverts balances to their original values.
 */
public class TransferSimulator {
    public void simulate(Account from, Account to, double amount) throws Exception {
        double fb = from.getBalance();
        double tb = to.getBalance();
        try {
            from.withdraw(amount); // may throw InsufficientBalanceException
            to.deposit(amount);
        } catch (Exception ex) {
            // rollback to original state
            // (Because we mutated domain objects directly)
            while (from.getBalance() < fb) { from.deposit(Math.min(fb - from.getBalance(), amount)); }
            while (to.getBalance() > tb) {
                // We cannot withdraw from 'to' abstractly without rules; assume safe revert by difference
                double delta = to.getBalance() - tb;
                try { to.withdraw(delta); } catch (InsufficientBalanceException e) { /* ignore for demo */ }
            }
            throw ex;
        }
    }
}
