
package com.smartbank.service;

import com.smartbank.model.Account;
import com.smartbank.model.exceptions.InsufficientBalanceException;

import java.util.concurrent.locks.ReentrantLock;

/**
 * Demonstrates explicit lock-based concurrency to avoid data races and deadlocks.
 * HOW: Acquire two account locks in a deterministic order (by accountNumber),
 * perform withdraw/deposit, then release locks. This mirrors DB-level isolation
 * but at the domain layer for educational purposes.
 */
public class LockedTransferService {
    private final BankRepository repo;

    public LockedTransferService(BankRepository repo) { this.repo = repo; }

    public void transfer(String fromAcc, String toAcc, double amount) throws InsufficientBalanceException {
        Account a = repo.getAccount(fromAcc);
        Account b = repo.getAccount(toAcc);
        if (a == null || b == null) throw new IllegalArgumentException("Account not found");

        // Order locks by account number to prevent deadlock
        Account first = a.getAccountNumber().compareTo(b.getAccountNumber()) <= 0 ? a : b;
        Account second = (first == a) ? b : a;
        ReentrantLock l1 = first.getLock();
        ReentrantLock l2 = second.getLock();

        l1.lock();
        try {
            l2.lock();
            try {
                if (a == first) {
                    a.withdraw(amount);
                    b.deposit(amount);
                } else {
                    b.withdraw(amount);
                    a.deposit(amount);
                }
                // In a real system we would persist deltas here
            } finally {
                l2.unlock();
            }
        } finally {
            l1.unlock();
        }
    }
}
