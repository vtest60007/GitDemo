package BookEx;

public class utility {
	public boolean validateBookId(String bookId) throws InvalidBookIdException
	{
		if(bookId.matches("^BOOK\\d{3}.*$")) {
			return true;
		}
		throw new InvalidBookIdException("Book Id "+bookId+" is not valid");
	}
}
