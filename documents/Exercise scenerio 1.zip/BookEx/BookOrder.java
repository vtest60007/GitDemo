package BookEx;

import java.util.*;

public class BookOrder {
	private List<Book> bookList=new ArrayList<Book>();
	private double discount;
	
	public void bookBooking(Book bookObject[]) {
		for(Book i:bookObject) {
			bookList.add(i);
		}
	}
	
	public void findDiscount(String paymentMethod) {
		if(paymentMethod.equals("CreditCard")) discount=20;
		else if(paymentMethod.equals("DebitCard")) discount=15;
		else if(paymentMethod.equals("NetBanking")) discount=10;
		else discount=0;
	}
	
	public double calculateTotalBill() {
		double totalBill=0, billAmount=0;
		for(Book i:bookList) {
			totalBill+= (i.getPricePerUnit()*i.getQuantity());
		}
		billAmount= totalBill-(totalBill*discount/100);
		return billAmount;
	}
}
