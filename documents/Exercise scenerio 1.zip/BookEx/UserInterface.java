package BookEx;

import java.util.*;
public class UserInterface {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		List<Book> bookList= new ArrayList<Book>();
		BookOrder bo=new BookOrder();
		utility u=new utility();
		System.out.println("Enter the total number of books needed");
		int n=sc.nextInt();
	
		System.out.println("Enter the Book details");
		boolean f=false;
		for(int i=0;i<n;i++) {
			String s=sc.next();
			String[] sar= s.split(":");
			try {
				f=u.validateBookId(sar[0]);
			}
			catch(InvalidBookIdException e) {
				System.out.println(e.getMessage());
			}
			if(f==true) {
				Book b= new Book(sar[0],sar[1],Double.parseDouble(sar[2]),Integer.parseInt(sar[3]));
				bookList.add(b);
			}
		}
		Book[] bookDetails= bookList.toArray(new Book[bookList.size()]);
		if(bookDetails==null || bookDetails.length==0) {
			System.out.println("Your booking is empty");
			return;
		}
		bo.bookBooking(bookDetails);
		System.out.println("Enter the payment method");
		String payType= sc.next();
		bo.findDiscount(payType);
		double bill= bo.calculateTotalBill();
		System.out.printf("Total Bill Amount: %.2f",bill);
		sc.close();
	}
}