package BookEx;

public class Book {
		private String bookId;
		private String bookName;
		private double pricePerUnit;
		private int quantity;
		
		public void setBookId(String bookId) {
			this.bookId=bookId;
		}
		public String getBookId() {
			return bookId;
		}
		public void setBookName(String bookName) {
			this.bookName=bookName;
		}
		public String getBookName() {
			return bookName;
		}
		public void setPricePerUnit(double pricePerUnit) {
			this.pricePerUnit=pricePerUnit;
		}
		public double getPricePerUnit() {
			return pricePerUnit;
		}
		public void setQuantity(int quantity) {
			this.quantity=quantity;
		}
		public int getQuantity() {
			return quantity;
		}
		
		public Book(String bookId, String bookName, double pricePerUnit, int quantity) {
			this.bookId=bookId;
			this.bookName=bookName;
			this.pricePerUnit=pricePerUnit;
			this.quantity=quantity;
		}
}
