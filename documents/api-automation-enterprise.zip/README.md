
# Enterprise API Automation Framework

## Features
- RestAssured setup
- TestNG execution
- Data-driven testing
- API chaining
- Logging

## Concepts

### API Testing
Validates REST endpoints using HTTP methods.

### Chaining
Use output of one API as input to another.

### Data-driven Testing
Run tests with multiple data sets.

### Logging
Helps debug failures.

## Run
mvn clean test
