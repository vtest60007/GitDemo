package utils;

import org.testng.annotations.DataProvider;

// Data provider for data-driven testing
public class TestData {

    @DataProvider(name = "users")
    public Object[][] users() {
        return new Object[][]{
            {"Alice", "Developer"},
            {"Bob", "Tester"},
            {"Charlie", "Manager"}
        };
    }
}
