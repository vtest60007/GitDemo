package base;

import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;

// Base class to initialize common config
public class BaseTest {

    @BeforeClass
    public void setup() {
        // Base URI setup for all tests
        RestAssured.baseURI = "https://reqres.in/api";
    }
}
