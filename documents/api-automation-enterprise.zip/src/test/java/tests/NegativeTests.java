package tests;

import base.BaseTest;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

// Negative scenarios
public class NegativeTests extends BaseTest {

    @Test
    public void invalidUser() {
        given()
        .when()
            .get("/users/9999")
        .then()
            .statusCode(404);
    }
}
