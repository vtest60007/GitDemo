package tests;

import base.BaseTest;
import org.json.JSONObject;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class UserFlowTests extends BaseTest {

    int userId;

    // End-to-end flow: create -> get -> delete
    @Test
    public void userFlow() {

        JSONObject req = new JSONObject();
        req.put("name", "Venkat");
        req.put("job", "QA");

        // CREATE USER
        userId =
        given().log().all()
            .header("Content-Type", "application/json")
            .body(req.toString())
        .when().log().all()
            .post("/users")
        .then().log().all()
            .statusCode(201)
            .body("id", notNullValue())
            .extract().path("id");

        // GET USER
        given()
        .when()
            .get("/users/" + userId)
        .then()
            .statusCode(anyOf(is(200), is(404)));

        // DELETE USER
        given()
        .when()
            .delete("/users/" + userId)
        .then()
            .statusCode(anyOf(is(204), is(200)));
    }
}
