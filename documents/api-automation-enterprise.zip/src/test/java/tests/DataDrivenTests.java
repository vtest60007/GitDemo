package tests;

import base.BaseTest;
import org.json.JSONObject;
import org.testng.annotations.Test;
import utils.TestData;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

// Multiple user creation using DataProvider
public class DataDrivenTests extends BaseTest {

    @Test(dataProvider = "users", dataProviderClass = TestData.class)
    public void createMultipleUsers(String name, String job) {

        JSONObject req = new JSONObject();
        req.put("name", name);
        req.put("job", job);

        given()
            .header("Content-Type", "application/json")
            .body(req.toString())
        .when()
            .post("/users")
        .then()
            .statusCode(201)
            .body("name", equalTo(name));
    }
}
