
# SmartBank - 12 Day Implementation Roadmap

Day 1: Domain modeling, OOP skeletons
Day 2: Encapsulation, this/super, final, static utilities
Day 3: Strings, arrays (temporary), custom exceptions
Day 4: Collections (List/Set/Map), Iterator
Day 5: Patterns I (Singleton, Factory)
Day 6: Patterns II (Strategy, Observer)
Day 7: JDBC setup, DAO with PreparedStatement
Day 8: CRUD + Transactions (commit/rollback/savepoints)
Day 9: Multithreading (Runnable, sleep/join), thread-safety
Day 10: File handling (BufferedReader/Writer), audit logs
Day 11: Java 8 (Streams/Lambdas/Optional/Generics, Comparable/Comparator)
Day 12: Annotations, CLI, integration & polishing
