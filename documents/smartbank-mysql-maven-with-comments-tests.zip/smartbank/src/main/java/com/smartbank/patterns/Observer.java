
package com.smartbank.patterns;

import com.smartbank.model.Customer;

/** Observer contract for notifications. */
public interface Notifier { void notify(Customer customer, String message); }

/** Email notifier stub. */
class EmailNotifier implements Notifier {
    @Override
    public void notify(Customer customer, String message) {
        System.out.printf("Email to %s: %s%n", customer.getEmail(), message);
    }
}

/** SMS notifier stub (reuses email field for demo). */
class SmsNotifier implements Notifier {
    @Override
    public void notify(Customer customer, String message) {
        System.out.printf("SMS to %s: %s%n", customer.getEmail(), message);
    }
}
