
package com.smartbank.model;

/** Enum used by Factory to create concrete accounts */
public enum AccountType { SAVINGS, CURRENT }
