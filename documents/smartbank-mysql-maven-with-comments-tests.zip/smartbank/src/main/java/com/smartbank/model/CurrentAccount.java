
package com.smartbank.model;

import com.smartbank.util.BankConstants;
import com.smartbank.model.exceptions.InsufficientBalanceException;

/**
 * CurrentAccount: allows overdraft up to a fixed limit; no interest.
 */
public class CurrentAccount extends Account {
    public CurrentAccount(String accountNumber, Customer owner, double openingBalance) {
        super(accountNumber, owner, openingBalance);
    }
    @Override
    public void withdraw(double amount) throws InsufficientBalanceException {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        double prospective = balance - amount;
        // Validates knowledge of final/static constants and rule enforcement
        if (prospective < -BankConstants.CURRENT_OVERDRAFT_LIMIT) {
            throw new InsufficientBalanceException("Overdraft limit exceeded");
        }
        balance -= amount;
    }
    @Override
    public double calculateInterest() { return 0.0; }
}
