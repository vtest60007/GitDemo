
package com.smartbank.model;

import com.smartbank.model.exceptions.InsufficientBalanceException;

/**
 * Abstract base class for all account types.
 *
 * WHY: Encapsulates shared state/behaviour and enables polymorphism so callers
 * can work with an Account reference while concrete classes specialise rules.
 * HOW: Holds core fields and implements shared logic (deposit). Subclasses
 * implement withdrawal rules and interest calculation.
 */
public abstract class Account {
    // Immutable unique identifier; encapsulated via getter only
    private final String accountNumber;
    // Owner reference encapsulated; subclasses can access balance through protected
    private Customer owner;
    // Protected: allows subclasses to enforce rules while mutating balance safely
    protected double balance;

    /**
     * Using 'this'/'super': constructor is chained from subclasses via super(...)
     */
    protected Account(String accountNumber, Customer owner, double openingBalance) {
        this.accountNumber = accountNumber; // 'this' refers to current object
        this.owner = owner;
        this.balance = openingBalance;
    }

    /**
     * Shared deposit logic with input validation.
     * Demonstrates unchecked exceptions for precondition violations.
     */
    public void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        balance += amount;
    }

    /**
     * Subclasses must implement their specific withdrawal rule.
     */
    public abstract void withdraw(double amount) throws InsufficientBalanceException;

    /**
     * Different account types calculate interest differently (Strategy-friendly).
     */
    public abstract double calculateInterest();

    public String getAccountNumber() { return accountNumber; }
    public double getBalance() { return balance; }
    public Customer getOwner() { return owner; }
}
