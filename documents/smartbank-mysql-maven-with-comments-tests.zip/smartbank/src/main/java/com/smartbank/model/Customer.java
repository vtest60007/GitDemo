
package com.smartbank.model;

import java.time.Instant;
import java.util.UUID;

/**
 * Simple immutable-id Customer.
 * WHY: Encapsulation of customer properties, with basic String handling.
 * HOW: Trims inputs, computes a derived full name, and generates a UUID.
 */
public class Customer {
    private final String id; // final to demonstrate immutability of identity
    private String firstName;
    private String lastName;
    private String email;
    private Instant createdAt;

    public Customer(String firstName, String lastName, String email) {
        this.id = UUID.randomUUID().toString();
        this.firstName = firstName.trim();
        this.lastName = lastName.trim();
        this.email = email.trim();
        this.createdAt = Instant.now();
    }

    public String getId() { return id; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getEmail() { return email; }

    /**
     * Demonstrates String ops (trim/concat/upper).
     */
    public String getFullName() { return (firstName + " " + lastName).toUpperCase(); }
}
