
package com.smartbank.service;

import com.smartbank.model.Account;

import java.sql.Connection;
import java.sql.Savepoint;

/**
 * TransferService demonstrates JDBC transactions with commit/rollback/savepoints.
 * HOW: Turns auto-commit off, performs a multi-step update, sets a savepoint,
 * commits on success or rolls back on any exception.
 */
public class TransferService {
    private final Connection conn;
    private final com.smartbank.dao.AccountDao accountDao;
    private final com.smartbank.dao.TransactionDao txDao;

    public TransferService(Connection conn, com.smartbank.dao.AccountDao accountDao, com.smartbank.dao.TransactionDao txDao) {
        this.conn = conn; this.accountDao = accountDao; this.txDao = txDao;
    }

    public void transfer(String fromAcc, String toAcc, double amount) throws Exception {
        conn.setAutoCommit(false); // start transaction
        Savepoint sp = null;
        try {
            Account src = accountDao.findByNumber(fromAcc);
            Account dst = accountDao.findByNumber(toAcc);

            src.withdraw(amount); // may throw custom checked exception
            dst.deposit(amount);

            accountDao.updateBalance(src.getAccountNumber(), src.getBalance());
            accountDao.updateBalance(dst.getAccountNumber(), dst.getBalance());

            txDao.insert(fromAcc, "DEBIT", amount);
            txDao.insert(toAcc, "CREDIT", amount);

            sp = conn.setSavepoint("AFTER_TX"); // demonstrate savepoint
            conn.commit(); // all-or-nothing
        } catch (Exception ex) {
            if (sp != null) conn.rollback(sp); else conn.rollback();
            throw ex; // propagate
        } finally {
            conn.setAutoCommit(true); // restore
        }
    }
}
