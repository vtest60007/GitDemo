
package com.smartbank.service;

import com.smartbank.model.Account;
import com.smartbank.model.AccountSummary;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * ReportsService demonstrates Java 8 Streams/Lambdas/Comparator usage.
 * WHY: Functional reporting pipelines over collections.
 */
public class ReportsService {
    /** Top-N accounts by balance (descending). */
    public List<AccountSummary> topAccounts(Collection<Account> accounts, int limit) {
        return accounts.stream()
            .sorted(Comparator.comparingDouble(Account::getBalance).reversed())
            .limit(limit)
            .map(a -> new AccountSummary(a.getAccountNumber(), a.getBalance()))
            .collect(Collectors.toList());
    }

    /** Total bank balance using map+reduce. */
    public double totalBalance(Collection<Account> accounts) {
        return accounts.stream().mapToDouble(Account::getBalance).sum();
    }
}
