
package com.smartbank.model;

import java.time.Instant;

/**
 * Transaction: immutable snapshot of a movement.
 * WHY: To persist audit trail via JDBC/File and iterate via Collections.
 */
public class Transaction {
    private final String accountNumber;
    private final String type; // CREDIT/DEBIT
    private final double amount;
    private final Instant createdAt = Instant.now();

    public Transaction(String accountNumber, String type, double amount) {
        this.accountNumber = accountNumber;
        this.type = type;
        this.amount = amount;
    }
    public String getAccountNumber() { return accountNumber; }
    public String getType() { return type; }
    public double getAmount() { return amount; }
    public Instant getCreatedAt() { return createdAt; }
}
