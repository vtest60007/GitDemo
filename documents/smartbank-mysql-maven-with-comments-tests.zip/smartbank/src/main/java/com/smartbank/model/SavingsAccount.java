
package com.smartbank.model;

import com.smartbank.util.BankConstants;
import com.smartbank.model.exceptions.InsufficientBalanceException;

/**
 * SavingsAccount: cannot go below 0; earns interest.
 * WHY: Specialised withdrawal rule validates OOP/Polymorphism.
 * HOW: Overrides withdraw and calculateInterest using constants.
 */
public class SavingsAccount extends Account {
    public SavingsAccount(String accountNumber, Customer owner, double openingBalance) {
        super(accountNumber, owner, openingBalance); // 'super' constructor chaining
    }
    @Override
    public void withdraw(double amount) throws InsufficientBalanceException {
        if (amount > balance) throw new InsufficientBalanceException("Insufficient funds");
        balance -= amount;
    }
    @Override
    public double calculateInterest() {
        return getBalance() * BankConstants.SAVINGS_INTEREST_RATE;
    }
}
