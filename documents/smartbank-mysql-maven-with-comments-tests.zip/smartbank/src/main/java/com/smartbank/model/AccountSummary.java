
package com.smartbank.model;

/**
 * DTO used in reports; shows Comparable/Comparator usage externally.
 */
public class AccountSummary {
    private final String accountNumber;
    private final double balance;
    public AccountSummary(String accountNumber, double balance) {
        this.accountNumber = accountNumber; this.balance = balance;
    }
    public String getAccountNumber() { return accountNumber; }
    public double getBalance() { return balance; }
}
