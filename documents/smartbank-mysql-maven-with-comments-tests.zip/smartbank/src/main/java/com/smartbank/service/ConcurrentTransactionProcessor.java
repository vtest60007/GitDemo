
package com.smartbank.service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Simple wrapper around ExecutorService.
 * WHY: Demonstrates thread pool, Runnable tasks, and join via Future#get.
 */
public class ConcurrentTransactionProcessor {
    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    public Future<?> submit(Runnable task) { return executor.submit(task); }
    public void shutdown() { executor.shutdown(); }
}
