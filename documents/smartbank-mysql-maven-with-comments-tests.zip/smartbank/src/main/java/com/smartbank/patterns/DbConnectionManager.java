
package com.smartbank.patterns;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Singleton that owns the JDBC Connection.
 * WHY: Ensures a single, shared connection lifecycle; demonstrates Singleton.
 */
public final class DbConnectionManager {
    private static volatile DbConnectionManager INSTANCE; // double-checked locking
    private Connection connection;

    private DbConnectionManager() {}

    public static DbConnectionManager getInstance() {
        if (INSTANCE == null) {
            synchronized (DbConnectionManager.class) {
                if (INSTANCE == null) INSTANCE = new DbConnectionManager();
            }
        }
        return INSTANCE;
    }

    /** Initialise the connection once. */
    public void init(String url, String user, String pass) throws SQLException {
        this.connection = DriverManager.getConnection(url, user, pass);
    }
    public Connection getConnection() { return connection; }
}
