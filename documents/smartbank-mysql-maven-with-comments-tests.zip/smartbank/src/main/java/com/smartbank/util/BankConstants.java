
package com.smartbank.util;

/**
 * Centralised constants and static helpers.
 * WHY: Demonstrates static members and final constants.
 */
public final class BankConstants {
    private BankConstants() {}
    public static final double SAVINGS_INTEREST_RATE = 0.035; // final constants
    public static final double CURRENT_OVERDRAFT_LIMIT = 10000.0;

    public static String generateAccountNumber() { // static utility method
        return "SB-" + System.currentTimeMillis();
    }
}
