
package com.smartbank.service;

import com.smartbank.annotations.Auditable;
import com.smartbank.model.Account;
import com.smartbank.model.Customer;
import com.smartbank.patterns.Notifier;

import java.util.ArrayList;
import java.util.List;

/**
 * AccountService applies business operations and emits Observer notifications.
 */
public class AccountService {
    private final BankRepository repo;
    private final List<Notifier> notifiers = new ArrayList<>();

    public AccountService(BankRepository repo) { this.repo = repo; }
    public void addNotifier(Notifier n) { notifiers.add(n); }

    private void notifyAll(Customer c, String msg) {
        notifiers.forEach(n -> n.notify(c, msg));
    }

    /** Demonstrates @Auditable and business method */
    @Auditable("deposit")
    public void deposit(String accountNumber, double amount) {
        Account acc = repo.getAccount(accountNumber);
        acc.deposit(amount);
        notifyAll(acc.getOwner(), "Deposit of " + amount + " to " + accountNumber);
    }
}
