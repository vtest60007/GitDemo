
package com.smartbank.util;

import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

/**
 * Simple file-based audit logger using character streams.
 * WHY: Validates FileReader/FileWriter, BufferedWriter concepts.
 */
public class AuditLogger implements Closeable {
    private final BufferedWriter writer;
    public AuditLogger(String path) throws IOException {
        this.writer = new BufferedWriter(new FileWriter(path, true));
    }
    public synchronized void log(String message) throws IOException {
        writer.write(LocalDateTime.now() + " | " + message);
        writer.newLine();
        writer.flush();
    }
    @Override public void close() throws IOException { writer.close(); }
}
