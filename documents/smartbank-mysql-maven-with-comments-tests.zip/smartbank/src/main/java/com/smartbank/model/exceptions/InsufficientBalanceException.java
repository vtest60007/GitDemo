
package com.smartbank.model.exceptions;

/**
 * Custom checked exception used in business rules.
 * WHY: Distinguish business rule failures from generic runtime errors.
 */
public class InsufficientBalanceException extends Exception {
    public InsufficientBalanceException(String message) { super(message); }
}
