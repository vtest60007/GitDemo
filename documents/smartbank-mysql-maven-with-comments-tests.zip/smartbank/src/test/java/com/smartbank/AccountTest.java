
package com.smartbank;

import com.smartbank.model.*;
import com.smartbank.model.exceptions.InsufficientBalanceException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/** Unit tests validating OOP rules and exceptions. */
public class AccountTest {
    @Test
    void savingsWithdrawWithinBalance() throws Exception {
        Customer c = new Customer("Ada", "Lovelace", "ada@smartbank");
        Account acc = new SavingsAccount("SB-1", c, 1000);
        acc.withdraw(200);
        assertEquals(800, acc.getBalance());
    }

    @Test
    void currentAccountOverdraftLimit() {
        Customer c = new Customer("Alan", "Turing", "alan@smartbank");
        Account acc = new CurrentAccount("SB-2", c, 100);
        assertThrows(InsufficientBalanceException.class, () -> acc.withdraw(10200));
    }
}
