
package com.smartbank;

import com.smartbank.model.*;
import com.smartbank.service.BankRepository;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

/** Validates Collections: List/Set/Map/Optional. */
public class BankRepositoryTest {
    @Test
    void addAndLookupAccounts() {
        BankRepository repo = new BankRepository();
        Customer c = new Customer("Grace", "Hopper", "grace@smartbank");
        repo.addCustomer(c);
        repo.addAccount(new SavingsAccount("SB-100", c, 1000));
        repo.addAccount(new CurrentAccount("SB-101", c, 500));
        List<Account> list = repo.getAccounts(c);
        assertEquals(2, list.size());
        assertTrue(repo.findCustomerByEmail("grace@smartbank").isPresent());
    }
}
