
package com.smartbank;

import com.smartbank.model.*;
import com.smartbank.service.ReportsService;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

/** Validates Streams/Lambdas/Comparator reporting. */
public class ReportsServiceTest {
    @Test
    void topAccountsByBalance() {
        Customer c = new Customer("Jane", "Doe", "jane@smartbank");
        List<Account> accounts = Arrays.asList(
                new SavingsAccount("A1", c, 5000),
                new CurrentAccount("A2", c, 2000),
                new SavingsAccount("A3", c, 7000)
        );
        ReportsService svc = new ReportsService();
        var top = svc.topAccounts(accounts, 2);
        assertEquals("A3", top.get(0).getAccountNumber());
        assertEquals("A1", top.get(1).getAccountNumber());
        assertEquals(14000, svc.totalBalance(accounts));
    }
}
