# SmartBank - Banking Management System (MySQL + Maven)

## Requirements
- Java 11+
- Maven 3+
- MySQL 8+

## Setup
1. Create MySQL schema:
   ```bash
   mysql -u root -p < src/main/resources/schema.sql
   ```
2. Update `src/main/resources/application.properties` with your DB credentials.

## Build
```bash
mvn clean package
```
This produces `target/smartbank-1.0-SNAPSHOT-jar-with-dependencies.jar`.

## Run
```bash
java -jar target/smartbank-1.0-SNAPSHOT-jar-with-dependencies.jar
```

## Notes
- Default connection URL: `jdbc:mysql://localhost:3306/smartbank`
- Ensure MySQL server is running.

## Day-wise Roadmap
See `docs/roadmap-12-days.md`.
