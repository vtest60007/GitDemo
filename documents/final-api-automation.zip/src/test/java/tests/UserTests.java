package tests;
import base.BaseTest;
import org.json.JSONObject;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
public class UserTests extends BaseTest {
@Test
public void fullFlow() {
JSONObject req=new JSONObject();
req.put("name","Venkat");
req.put("job","QA");
String id=
given().log().all()
.header("Content-Type","application/json")
.body(req.toString())
.when().post("/users")
.then().log().all()
.statusCode(201)
.extract().path("id");

given().get("/users/"+id)
.then().statusCode(anyOf(is(200),is(404)));

given().delete("/users/"+id)
.then().statusCode(anyOf(is(204),is(200)));
}
}