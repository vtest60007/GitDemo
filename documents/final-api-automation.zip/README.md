
# API Automation Enterprise Framework

## Overview
Complete API automation framework using RestAssured + TestNG.

## Features
- Config management
- Data-driven testing
- API chaining
- Logging
- Retry mechanism
- Ready for CI/CD

## How to Run
mvn clean test

## Key Concepts
API Testing, HTTP methods, validations, authentication, schema validation.
