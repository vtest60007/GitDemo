import static io.restassured.RestAssured.*;

public class Practice {
    public void testAPI(){
        given().when().get("https://jsonplaceholder.typicode.com/posts").then().statusCode(200);
        given().when().get("https://fakestoreapi.com/products").then().statusCode(200);
        given().when().get("https://dummyjson.com/products").then().statusCode(200);
    }
}
