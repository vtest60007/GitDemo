package base;

import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;
import utils.ConfigReader;

// Base class for common setup
public class BaseTest {

    @BeforeClass
    public void setup() {
        // Load base URL dynamically
        RestAssured.baseURI = ConfigReader.get("base_url");

        // Ignore SSL issues (useful in test environments)
        RestAssured.useRelaxedHTTPSValidation();
    }
}
