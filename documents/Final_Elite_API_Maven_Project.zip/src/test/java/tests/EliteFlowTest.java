package tests;

import base.BaseTest;
import io.qameta.allure.Description;
import org.json.JSONObject;
import org.testng.annotations.Test;
import utils.RequestBuilder;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

// Full CRUD API Flow Test
public class EliteFlowTest extends BaseTest {

    @Test(retryAnalyzer = utils.Retry.class)
    @Description("End-to-end API flow with validation")
    public void fullFlow() {

        // Step 1: Create resource
        JSONObject req = new JSONObject();
        req.put("title", "elite");
        req.put("body", "framework");
        req.put("userId", 1);

        int id = RequestBuilder.request()
                .body(req.toString())
        .when()
                .post("/posts")
        .then()
                .statusCode(201)
                .body("title", equalTo("elite"))
                .extract().path("id");

        // Step 2: Get resource
        given().log().all()
        .when()
                .get("/posts/" + id)
        .then()
                .statusCode(200);

        // Step 3: Update resource
        req.put("title", "updated");

        RequestBuilder.request()
                .body(req.toString())
        .when()
                .put("/posts/" + id)
        .then()
                .statusCode(200)
                .body("title", equalTo("updated"));

        // Step 4: Delete resource
        given().log().all()
        .when()
                .delete("/posts/" + id)
        .then()
                .statusCode(200);
    }
}
