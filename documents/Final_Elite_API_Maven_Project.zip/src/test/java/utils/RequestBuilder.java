package utils;

import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.*;

// Reusable request builder
public class RequestBuilder {

    public static RequestSpecification request() {
        return given()
                .header("Content-Type", "application/json")
                .log().all();
    }
}
