
package com.smartbank.app;

import com.smartbank.dao.AccountDao;
import com.smartbank.dao.CustomerDao;
import com.smartbank.model.*;
import com.smartbank.patterns.AccountFactory;
import com.smartbank.service.BankRepository;

/**
 * Seeds a few customers and accounts for demo/testing.
 */
public class DataLoader {
    private final CustomerDao customerDao;
    private final AccountDao accountDao;
    private final BankRepository repo;

    public DataLoader(CustomerDao customerDao, AccountDao accountDao, BankRepository repo) {
        this.customerDao = customerDao; this.accountDao = accountDao; this.repo = repo;
    }

    public void loadSampleData() throws Exception {
        Customer c1 = new Customer("Sita", "Raman", "sita@smartbank");
        Customer c2 = new Customer("Arun", "Prakash", "arun@smartbank");
        Customer c3 = new Customer("Meena", "Devi", "meena@smartbank");
        customerDao.insert(c1); customerDao.insert(c2); customerDao.insert(c3);
        repo.addCustomer(c1); repo.addCustomer(c2); repo.addCustomer(c3);

        Account a1 = AccountFactory.create(AccountType.SAVINGS, c1, 5000);
        Account a2 = AccountFactory.create(AccountType.CURRENT, c1, 2000);
        Account a3 = AccountFactory.create(AccountType.SAVINGS, c2, 15000);
        Account a4 = AccountFactory.create(AccountType.CURRENT, c3, 8000);
        accountDao.insert(a1, AccountType.SAVINGS);
        accountDao.insert(a2, AccountType.CURRENT);
        accountDao.insert(a3, AccountType.SAVINGS);
        accountDao.insert(a4, AccountType.CURRENT);
        repo.addAccount(a1); repo.addAccount(a2); repo.addAccount(a3); repo.addAccount(a4);
    }
}
