
package com.smartbank.app;

import com.smartbank.dao.AccountDao;
import com.smartbank.dao.CustomerDao;
import com.smartbank.dao.TransactionDao;
import com.smartbank.model.*;
import com.smartbank.patterns.AccountFactory;
import com.smartbank.patterns.DbConnectionManager;
import com.smartbank.patterns.EmailNotifier;
import com.smartbank.patterns.SmsNotifier;
import com.smartbank.service.BankRepository;
import com.smartbank.service.AccountService;
import com.smartbank.service.ReportsService;
import com.smartbank.service.TransferService;
import com.smartbank.util.PropertyLoader;

import java.sql.Connection;
import java.util.Scanner;

/**
 * Console entry point with extended menu to validate multiple concepts quickly.
 */
public class Main {
    public static void main(String[] args) throws Exception {
        PropertyLoader props = new PropertyLoader();
        String url = props.get("db.url");
        String user = props.get("db.username");
        String pass = props.get("db.password");

        DbConnectionManager db = DbConnectionManager.getInstance();
        db.init(url, user, pass);
        Connection conn = db.getConnection();

        CustomerDao customerDao = new CustomerDao(conn);
        AccountDao accountDao = new AccountDao(conn);
        TransactionDao txDao = new TransactionDao(conn);

        BankRepository repo = new BankRepository();
        AccountService accountService = new AccountService(repo);
        // Attach Observers (notifications)
        accountService.addNotifier(new EmailNotifier());
        accountService.addNotifier(new SmsNotifier());

        ReportsService reports = new ReportsService();
        TransferService transferService = new TransferService(conn, accountDao, txDao);
        DataLoader loader = new DataLoader(customerDao, accountDao, repo);

        Scanner sc = new Scanner(System.in);
        System.out.println("SmartBank CLI");
        while (true) {
            System.out.println("
Menu:");
            System.out.println("1) Create customer & savings account");
            System.out.println("2) Deposit");
            System.out.println("3) Transfer");
            System.out.println("4) Load sample data");
            System.out.println("5) Top 3 accounts by balance (Streams)");
            System.out.println("6) Total bank balance (reduce)");
            System.out.println("0) Exit");
            System.out.print("Choose: ");
            int ch;
            try { ch = Integer.parseInt(sc.nextLine()); } catch (Exception e) { continue; }
            if (ch == 0) break;
            switch (ch) {
                case 1: {
                    System.out.print("First name: "); String fn = sc.nextLine();
                    System.out.print("Last name: "); String ln = sc.nextLine();
                    System.out.print("Email: "); String em = sc.nextLine();
                    Customer c = new Customer(fn, ln, em);
                    customerDao.insert(c);
                    Account acc = AccountFactory.create(AccountType.SAVINGS, c, 1000.0);
                    accountDao.insert(acc, AccountType.SAVINGS);
                    repo.addCustomer(c);
                    repo.addAccount(acc);
                    System.out.println("Created account: " + acc.getAccountNumber());
                    break;
                }
                case 2: {
                    System.out.print("Account number: "); String accNo = sc.nextLine();
                    System.out.print("Amount: "); double amt = Double.parseDouble(sc.nextLine());
                    accountService.deposit(accNo, amt);
                    txDao.insert(accNo, "CREDIT", amt);
                    System.out.println("Deposited.");
                    break;
                }
                case 3: {
                    System.out.print("From account: "); String from = sc.nextLine();
                    System.out.print("To account: "); String to = sc.nextLine();
                    System.out.print("Amount: "); double amt = Double.parseDouble(sc.nextLine());
                    try {
                        transferService.transfer(from, to, amt);
                        System.out.println("Transferred.");
                    } catch (Exception ex) {
                        System.out.println("Transfer failed: " + ex.getMessage());
                    }
                    break;
                }
                case 4: {
                    loader.loadSampleData();
                    System.out.println("Sample data loaded.");
                    break;
                }
                case 5: {
                    var top = reports.topAccounts(repo.getAllAccounts(), 3);
                    top.forEach(s -> System.out.println(s.getAccountNumber() + " -> " + s.getBalance()));
                    break;
                }
                case 6: {
                    double total = reports.totalBalance(repo.getAllAccounts());
                    System.out.println("Total balance: " + total);
                    break;
                }
            }
        }
        sc.close();
    }
}
