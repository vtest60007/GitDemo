
package com.smartbank;

import com.smartbank.service.AccountService;
import com.smartbank.service.BankRepository;
import com.smartbank.util.AnnotationAuditor;
import com.smartbank.util.AuditLogger;
import org.junit.jupiter.api.Test;

import java.io.File;

import static org.junit.jupiter.api.Assertions.assertTrue;

/** Validates custom annotations + reflection scanning */
public class AnnotationAuditorTest {
    @Test
    void scanAuditableMethods() throws Exception {
        BankRepository repo = new BankRepository();
        AccountService svc = new AccountService(repo);
        File f = new File("target/test-audit.log");
        try (AuditLogger logger = new AuditLogger(f.getPath())) {
            AnnotationAuditor.scanAndLog(svc, logger);
        }
        assertTrue(f.exists());
        assertTrue(f.length() > 0);
    }
}
