
package com.smartbank;

import com.smartbank.service.ConcurrentTransactionProcessor;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import static org.junit.jupiter.api.Assertions.assertEquals;

/** Validates thread pool execution and join semantics via Future#get. */
public class ConcurrencyTest {
    @Test
    void futuresComplete() throws Exception {
        ConcurrentTransactionProcessor tp = new ConcurrentTransactionProcessor();
        List<Future<?>> futures = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            futures.add(tp.submit(() -> {
                try { Thread.sleep(100); } catch (InterruptedException ignored) {}
            }));
        }
        int completed = 0;
        for (Future<?> f : futures) { f.get(); completed++; }
        tp.shutdown();
        assertEquals(5, completed);
    }
}
